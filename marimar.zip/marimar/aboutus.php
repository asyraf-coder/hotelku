<h1>About Us</h1>
  <div class="intro">
    <div class="container">
      <div class="row row-eq-height">

        <!-- Intro Content -->
        <div class="col-lg-6">
          <div class="intro_content">
            <div class="section_title">
              <div>Hello</div>
              <h1>Amazing Hotel in front of the Sea</h1>
            </div>
            <div class="intro_text">
              <p>Discover a slice of paradise at our Amazing Hotel in Front of the Sea, where the soothing sound of waves and breathtaking ocean views create the perfect setting for your dream getaway.</p>
            </div>
           <!--  <div class="button intro_button"><a href="#">read more</a></div> -->
          </div>
        </div>

        <!-- Intro Image -->
        <div class="col-lg-6">
          <div class="intro_image">
            <div class="background_image" style="background-image:url(images/intro.jpg)"></div>
            <img src="images/intro.jpg" alt="">
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Offering -->

  <div class="offering">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="section_title text-center">
            <div>Resort</div>
            <h1>What we offer</h1>
          </div>
        </div>
      </div>
      <div class="row offering_row">
        
        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_1.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Outdoor Pool</h3></div>
              <div class="offer_text">
                <p>Relax and unwind in our outdoor pool, surrounded by stunning views and a tranquil atmosphere. Whether you're taking a refreshing swim or lounging by the poolside, this is the perfect spot to soak up the sun and enjoy the beauty of nature.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_2.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Indoor Pool</h3></div>
              <div class="offer_text">
                <p>Enjoy a serene swim in our heated indoor pool, offering comfort and relaxation no matter the weather. Ideal for both leisurely laps and peaceful moments, our indoor pool is a haven of calm and indulgence.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_3.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Spa Zone</h3></div>
              <div class="offer_text">
                <p>Stay active and energized in our well-equipped sports area, featuring facilities for a variety of activities. Whether you're a fitness enthusiast or looking for some fun, there's something for everyone.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_4.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Sports Area</h3></div>
              <div class="offer_text">
                <p>Stay active and energized in our well-equipped sports area, featuring facilities for a variety of activities. Whether you're a fitness enthusiast or looking for some fun, there's something for everyone.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_5.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Restaurant</h3></div>
              <div class="offer_text">
                <p>Savor delectable dishes and fresh, locally sourced ingredients at our on-site restaurant. With a menu crafted to delight every palate, dining here is an experience to remember.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

        <!-- Offer Item -->
        <div class="col-xl-4 col-md-6">
          <div class="offer">
            <div class="offer_image"><img src="images/offer_6.jpg" alt=""></div>
            <div class="offer_content text-center">
              <div class="offer_title"><h3>Skybar</h3></div>
              <div class="offer_text">
                <p>Elevate your evenings at our Skybar, where breathtaking views meet exceptional cocktails. Whether you're celebrating or unwinding, our Skybar offers a sophisticated setting for memorable moments.</p>
              </div>
            <!--   <div class="offer_button"><a href="#">discover</a></div> -->
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <!-- Discover -->

  <div class="discover">

    <!-- Discover Content -->
    <div class="discover_content">
      <div class="container">
        <div class="row">

          <!-- Discover Content -->
          <div class="col-xl-5 col-lg-6">
            <div class="section_title">
              <div>Hotel</div>
              <h1>Discover Marimar Hotel</h1>
            </div>
            <div class="discover_highlight">
              <p>Time flows harmoniously, blending seamlessly with relaxation. The design is elegant and refined, offering unmatched comfort. Enjoy a setting where every detail is crafted for your satisfaction.</p>
            </div>
            <div class="discover_text">
              <p>Time flows smoothly, creating an atmosphere of relaxation and ease. The design is minimal yet sophisticated, offering both style and comfort. Enjoy a harmonious blend of elements that enhance the experience, from the serene ambiance to the subtle details. The space is perfect for unwinding or enjoying a moment of peace. Every aspect is thoughtfully designed to provide an extraordinary experience.</p>
            </div>
            <div class="button discover_button"><a href="#">discover</a></div>
          </div>

          <!-- Milestones -->
          <div class="col-lg-6 offset-xl-1">
            <div class="milestones d-flex flex-row align-items-start justify-content-start flex-wrap">
              
              <!-- Milestone -->
              <div class="milestone">
                <div class="milestone_counter" data-end-value="75">0</div>
                <div class="milestone_text">Deluxe Rooms</div>
              </div>

              <!-- Milestone -->
              <div class="milestone">
                <div class="milestone_counter" data-end-value="110">0</div>
                <div class="milestone_text">Years of Experience</div>
              </div>

              <!-- Milestone -->
              <div class="milestone">
                <div class="milestone_counter" data-end-value="31">0</div>
                <div class="milestone_text">Awards Won</div>
              </div>

              <!-- Milestone -->
              <div class="milestone">
                <div class="milestone_counter" data-end-value="51" data-sign-after="k">10</div>
                <div class="milestone_text">Happy Clients</div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>

  </div>
