  <?php
$msg = "";

if(isset($_POST['booknow'])){

    $days =0;
    $day = dateDiff($_SESSION['arrival'],$_SESSION['departure']);  

   if($day <= 0){
      $totalprice = $_POST['ROOMPRICE'] *1;
      $days = 1;
    }else{
      $totalprice = $_POST['ROOMPRICE'] * $day;
      $days = $day;
    }
     
      
      addtocart($_POST['ROOMID'],$days, $totalprice,$_SESSION['arrival'],$_SESSION['departure'],0);

      // redirect(WEB_ROOT. 'booking/'); 

}
 

 if(!isset($_SESSION['arrival'])){
   $_SESSION['arrival'] = date_create('Y-m-d');
 }
if(!isset($_SESSION['departure'])) {
  $_SESSION['departure'] =  date_create('Y-m-d') ;
}


if(isset($_POST['booknowA'])){ 


 $days = dateDiff($_POST['arrival'],$_POST['departure']); 

if($days <= 0){
  $msg = 'Available room today';
}else{
   $msg =  'Available room From:'.$_POST['arrival']. ' To: ' .$_POST['departure'];

} 


$_SESSION['arrival'] = date_format(date_create( $_POST['arrival']),"Y-m-d");
$_SESSION['departure'] =date_format(date_create($_POST['departure']),"Y-m-d");


 
 $query = "SELECT * FROM `tblroom` r ,`tblaccomodation` a WHERE r.`ACCOMID`=a.`ACCOMID`   AND `NUMPERSON` = " . $_POST['person'];
    

}elseif(isset($_GET['q'])){

    $query = "SELECT * FROM `tblroom` r ,`tblaccomodation` a WHERE r.`ACCOMID`=a.`ACCOMID` AND `ROOM`='" . $_GET['q'] . "'"; 
   
  
  }else{
     $query = "SELECT * FROM `tblroom` r ,`tblaccomodation` a WHERE r.`ACCOMID`=a.`ACCOMID`";
  }

   $accomodation = ' | ' . @$_GET['q'];
  ?>
  <div class="row">
        <div class="col">
          <div class="card-columns">

 
               
                <?php 
 
                  $arrival =  $_SESSION['arrival'];
                  $departure =  $_SESSION['departure'] ;

                   $mydb->setQuery($query);
                   $cur = $mydb->loadResultList(); 
                      foreach ($cur as $result) { 


// filtering the rooms
 // ======================================================================================================
 $mydb->setQuery("SELECT * FROM `tblreservation` WHERE STATUS<>'Pending' AND ((
  '$arrival' >= DATE_FORMAT(`ARRIVAL`,'%Y-%m-%d')
  AND  '$arrival' <= DATE_FORMAT(`DEPARTURE`,'%Y-%m-%d')
  )
  OR (
  '$departure' >= DATE_FORMAT(`ARRIVAL`,'%Y-%m-%d')
  AND  '$departure' <= DATE_FORMAT(`DEPARTURE`,'%Y-%m-%d')
  )
  OR (
  DATE_FORMAT(`ARRIVAL`,'%Y-%m-%d') >=  '$arrival'
  AND DATE_FORMAT(`ARRIVAL`,'%Y-%m-%d') <=  '$departure'
  )
  )
  AND ROOMID =".$result->ROOMID);

// Execute the query
$curs = $mydb->loadResultList(); 

// Calculate available room numbers
$resNum = $result->OROOMNUM - count($curs);

// Execute the query again for status
$stats = $mydb->executeQuery();

// Check if the query executed successfully and returned results
if ($stats) {
$rows = mysqli_fetch_assoc($stats);

// Check if rows is not null before accessing 'STATUS'
if ($rows) {
$status = $rows['STATUS'];
} else {
// Handle the case where no rows were returned
$status = 'No status available'; // or any appropriate default value
}
} else {
// Handle query execution error
echo "Query execution failed: " . mysqli_error($mydb->getConnection());
}

                     
                    //$availRoom = $result->ROOMNUM;


              if($resNum==0){

             if($status=='Confirmed'){
                $btn =  '<div style="margin-top:10px; color: rgba(0,0,0,1); font-size:16px;"><strong>Fully Reserve!</strong></div>';
                 $img_title = ' 

                           <figcaption class="img-title-active">
                                <h5>Reserve!</h5>    
                            </figcaption>


                    ';
              }elseif($status=='Checkedin'){
                $btn =  '<div style="margin-top:10px; color: rgba(0,0,0,1); font-size:16px;"><strong>Fully Book!</strong></div>';
                 $img_title = ' 

                           <figcaption class="img-title-active">
                                <h5>Book!</h5>    
                            </figcaption>


                    ';
              }else{
                 $btn =  '
                 <div class="form-group">
                        <div class="row">
                          <div class="col-xs-12 col-sm-12">
                            <input type="submit" class="button rooms_button"  id="booknow" name="booknow" onclick="return validateBook();" value="Book Now!"/>
                                                   
                           </div>
                        </div>
                      </div>';
                    $img_title = ' 

                           <figcaption class="img-title">
                                <h5>'.$result->ROOM . ' <br/> '.$result->ROOMDESC.'  <br/>
                                ' . $result->ACCOMODATION .' <br/> 
                                '.$result->ACCOMDESC . '<br/>  
                                Number of Person:' . $result->NUMPERSON .' <br/> 
                                Price:'.$result->PRICE.'</h5>    
                            </figcaption>


                    ';
                   
              }
                   
              }else{
                $btn =  '
                 <div class="form-group">
                        <div class="row">
                          <div class="col-xs-12 col-sm-12">
                            <input type="submit" class="button rooms_button" id="booknow" name="booknow" onclick="return validateBook();" value="Book Now!"/>
                                                   
                           </div>
                        </div>
                      </div>';
                    $img_title = ' 

                           <figcaption class="img-title">
                                <h5>'.$result->ROOM . ' <br/> '.$result->ROOMDESC.'  <br/>
                                ' . $result->ACCOMODATION .' <br/> 
                                '.$result->ACCOMDESC . '<br/>  
                                Number of Person:' . $result->NUMPERSON .' <br/> 
                                Price:'.$result->PRICE.'</h5>    
                            </figcaption>


                    ';
                   

              }      
// ============================================================================================================================

 
                ?>
                 <form method="POST" action="index.php?p=accomodation">
                 <input type="hidden" name="ROOMPRICE" value="<?php echo $result->PRICE ;?>">
                  <input type="hidden" name="ROOMID" value="<?php echo $result->ROOMID ;?>">

                      <div class="card">
                        <img class="card-img-top"  src="<?php echo WEB_ROOT .'admin/mod_room/'.$result->ROOMIMAGE; ?>" alt="Room image description">
                        <div class="card-body">
                          <div class="rooms_title"><h2><?php echo $result->ROOM ;?> <?php echo $result->ACCOMODATION ;?></h2></div>
                          <div class="rooms_text">
                            <p><?php echo $result->ROOMDESC ;?></p>
                          </div>
                          <div class="rooms_list">
                            <ul>
                              <li class="d-flex flex-row align-items-center justify-content-start">
                                <img src="images/check.png" alt="">
                                <span>Number of Person - <?php echo $result->NUMPERSON ;?></span>
                              </li> 
                              <li class="d-flex flex-row align-items-center justify-content-start">
                                <img src="images/check.png" alt="">
                                <span>Remaining Rooms :<?php echo  $resNum ;?></span>
                              </li>
                            </ul>
                          </div>
                          <div class="rooms_price"><?php echo   $result->PRICE ;?>/<span>Night</span></div>
                           <?php echo $btn ; ?> 
                        </div>
                      </div>

                  

                  </form>

        
                <?php  
 
                 }

                ?>

              </div> 
          </div>
    
    
 </div>